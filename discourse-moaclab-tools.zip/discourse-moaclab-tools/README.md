# Discourse Moaclab Tools

为 Moaclab 的 Theme Components 注册两个真正的 Discourse 页面：

- `/typing` → Ember 路由 `moaclab-typing`
- `/viewer` → Ember 路由 `moaclab-viewer`

插件只处理 Rails 应用壳、Ember 路由与刷新回退，不复制 Typing 或 CAD Viewer 的界面代码，也不增加数据表和后台任务。

## 为什么必须使用插件

`/?typing` 与 `/?viewer` 都属于首页/Discovery 路由。查询参数不会改变 Discourse 的当前 Ember 路由，因此分类或首页侧栏项可能与工具入口同时保持选中。真实路由可以让 Discourse 自己完成页面销毁、返回/前进、刷新和侧栏 current route 计算。

## 安装

把目录放入 Discourse 的 `plugins/discourse-moaclab-tools`，然后重建应用容器。插件不能作为 Theme Component 在后台上传。

如果之前安装过 `discourse-moaclab-typing-route`，先从容器配置中移除；旧插件只映射 Rails 页面壳，没有 Ember 路由，并且会与本插件的 `/typing` 重复。

```sh
cd /var/discourse
./launcher rebuild app
```

重建完成后，再分别更新并启用 `moaclab-typing` 与 `moaclab-cad-viewer` Theme Components。
